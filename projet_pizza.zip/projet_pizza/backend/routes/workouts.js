const express = require('express')

const workout=require('../models/workout_model')

const router = express.Router()


const {
    creatworkout,
    getworkouts,
    getworkout,
    createworkout,
    deletetworkout,
    updateworkout
}=require("../controllers/workoutController")


//get all workouts function
router.get('/',getworkouts)

//get a single workout by id in url function
router.get('/:id',getworkout)


router.post('/',createworkout)


router.delete('/:id',deletetworkout)


router.patch('/:id',updateworkout)

module.exports = router