const express = require('express')

const router = express.Router()

router.get('/',(req, res)=>{
    res.json({mssg:'Get all workouts'})
})

router.get('/:id',(req,res)=>{
    res.json({mssg:'Get a single workout'})
})
router.post('/',(req,res)=>{
    res.json({mssg:'Post a workout'})
})
router.delete('/:id',(req,res)=>{
    res.json({mssg:'delete a workout'})
})
router.patch('/:id',(req,res)=>{
    res.json({mssg:'update a workout'})
})

module.exports = router