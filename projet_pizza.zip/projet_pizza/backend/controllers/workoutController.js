const workout=require('../models/workout_model')

const mongoose= require('mongoose')

const getworkouts = async (req, res) =>{
    const workouts = await workout.find({}).sort({createdAt:-1})

    res.status(200).json(workouts)
}

const getworkout = async (req, res) =>{
    const {id}=req.params
    if(!mongoose.Types.ObjectId.isValid(id)){
        return  res.status(404).json({error:"No such workout"})
    }

    const workout1 = await workout.findById(id)
    if(!workout1){
        return res.status(404).json({error:"No such workout"})
    }
    res.status(200).json(workout1)
}

const createworkout = async(req, res)=>{
    const {title, reps, load}=req.body
    //add to data base
    try{
        const workout1 = await workout.create({title, reps, load})
        res.status(200).json(workout1)
    }catch(error){
        res.status(400).json({error:error.message})
    }
}

const deletetworkout = async (req, res) =>{
    const {id}=req.params
    if(!mongoose.Types.ObjectId.isValid(id)){
        return  res.status(404).json({error:"No such workout"})
    }
    
    const workout1 = await workout.findOneAndDelete({_id:id})
    if(!workout1){
        return res.status(404).json({error:"No such workout"})
    }
    res.status(200).json(workout1)
}

const updateworkout = async (req, res) =>{
    const {id}=req.params
    if(!mongoose.Types.ObjectId.isValid(id)){
        return  res.status(404).json({error:"No such workout"})
    }
    
    const workout1 = await workout.findOneAndUpdate({_id:id},{
        ...req.body
    })
    if(!workout1){
        return res.status(404).json({error:"No such workout"})
    }
    res.status(200).json(workout1)
}


module.exports={
    createworkout,
    getworkouts,
    getworkout,
    deletetworkout,
    updateworkout
}